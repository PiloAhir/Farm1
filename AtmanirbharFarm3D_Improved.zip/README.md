# Atmanirbhar Farm 3D Android project

## Build
- Open the repository in GitHub.
- GitHub Actions -> Build Android APK -> run workflow.
- Download `AtmanirbharFarm3D-debug-apk` from the successful workflow's Artifacts.

## Updated controls and graphics
- The movement arrows only move the first-person camera; they no longer trigger object selection.
- Tap an object in the 3D view to show its details. Dragging the view rotates the camera.
- Improved procedural ground texture, softer shadows, tone mapping, foliage and atmospheric depth.

## Notes
This remains a lightweight Three.js WebView prototype. It downloads Three.js from jsDelivr, so the 3D scene requires internet access. The procedural graphics are improved but are not equivalent to a photorealistic Unreal Engine scene; detailed realism would require high-quality 3D models and textures and more device-specific performance testing.
